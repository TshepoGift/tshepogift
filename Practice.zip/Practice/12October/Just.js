// Create an array of numbers.
const numbers = [1, 2, 3, 4, 5];

// Iterate over the array and print each number to the console.
for (let i = 0; i < numbers.length; i++) {
  console.log(numbers[i]);
}

// Create an object to store information about a person.
const person = {
  name: "John Doe",
  age: 30,
  occupation: "Software engineer",
};

// Access the person's name and print it to the console.
console.log(person.name); // John Doe

// Update the person's occupation.
person.occupation = "Web developer";

// Print the person's updated occupation to the console.
console.log(person.occupation); // Web developer
