// Create a student object.
const Student = {
    isActive: true,
    marks: [57, 99, 56, 12, 6],
    studentName: 'John Doe',
  
    printMarks:function() {
        //print all the marks for the student
      console.log(`Marks for student ${this.studentName}:`);
      for (const mark of this.marks) {
        console.log(mark);
      }
    },
  
    calculateAverage:function() {
        //Calculate the average for the student 
      const sumOfMarks = this.marks.reduce((sum, mark) => sum + mark, 0);
      return sumOfMarks / this.marks.length;
    },
  
    getPassedSubjects:function() {
        //create an array that only contains the subjects that the subjects passed USING LOOP
      const passedSubjects = [];
      for (const mark of this.marks) {
        if (mark >= 50) {
          passedSubjects.push(mark);
        }
      }
      return passedSubjects;
    },
  };
  
  // Print the student's marks.
  Student.printMarks();
  
  // Calculate the student's average mark.
  const averageMark = Student.calculateAverage();
  console.log(`Average mark for student ${Student.studentName}: ${averageMark}`);
  
  // Get the list of subjects that the student passed.
  const passedSubjects = Student.getPassedSubjects();
  console.log(`Passed subjects for student ${Student.studentName}: ${passedSubjects}`);
  
  // Create another student object.
  const otherStudent = new Object();
  