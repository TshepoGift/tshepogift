//object literal notation
let student ={
    studentName: "John",
    mark: 76,
    subject: "WPR261",
    /*We can also create methods */
    getMark: function(){
        console.log(this.mark);
    },
    setMark: function (mark){
        if(typeof mark === "number"){
            if(mark < 0 || mark>100){
                console.error("The mark may only be a value between 0 and 100");
            }else{
                this.mark=mark;
            }
        }else{
            console.error("The mark can only be a number");
        }
    },
};
student.getMark();
student.setMark(89);
student.getMark();

//object constructor
let anotherStudent = new Object();