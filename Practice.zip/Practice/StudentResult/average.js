// Array of subjects and their grades.
let subjects = [['Web Programming', 80], ['Internet of Things', 77], ['Mathematics', 88], ['End-Computer User', 95], ['Enterprise', 68]];

// Initialize the variable to store the total marks.
let Avgmarks = 0;

// Calculate the total marks for all subjects.
for (let i = 0; i < subjects.length; i++) {
    Avgmarks += subjects[i][1];
}

// Calculate the average grade by dividing the total marks by the number of subjects.
let avg = Avgmarks / subjects.length;

// Display the average grade to the user.
console.log("Average grade: " + avg);

// Determine the letter grade based on the average.
if (avg < 60) {
    console.log("Grade : F"); // Below 60 is an "F" grade.
} else if (avg < 70) {
    console.log("Grade : D"); // 60-69 is a "D" grade.
} else if (avg < 80) {
    console.log("Grade : C"); // 70-79 is a "C" grade.
} else if (avg < 90) {
    console.log("Grade : B"); // 80-89 is a "B" grade.
} else if (avg <= 100) { // Adjusted this condition to include 100.
    console.log("Grade : A"); // 90-100 is an "A" grade.
}

