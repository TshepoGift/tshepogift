// Function to calculate the result mark.
function calculateResultMark(totalMarks, numberOfSubjects) {
    // Check if numberOfSubjects is not zero to avoid division by zero.
    if (numberOfSubjects !== 0) {
      return totalMarks / numberOfSubjects;
    } else {
      // Handle the case where numberOfSubjects is zero to avoid division by zero.
      return "Number of subjects should be greater than zero.";
    }
  }
  
  // Function to display the result mark to the user.
  function displayResultMark(resultMark) {
    console.log(`Result mark: ${resultMark}`);
  }
  
  // Define the total marks obtained by the student.
  const totalMarks = 250;
  
  // Define the number of subjects.
  const numberOfSubjects = 3;
  
  // Calculate the result mark.
  const resultMark = calculateResultMark(totalMarks, numberOfSubjects);
  
  // Display the result mark to the user.
  displayResultMark(resultMark);
  