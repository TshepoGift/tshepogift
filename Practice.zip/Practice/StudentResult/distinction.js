// Define the student's score.
const score = 85;

// Define a threshold for distinctions.
const distinctionThreshold = 70;

// Initialize variables to store the grade and distinctions.
let grade = "";
let distinctions = "";

// Determine the grade based on the score.
if (score >= 90) {
    grade = "A";
    distinctions = "With Distinction";
} else if (score >= 80) {
    grade = "B";
    distinctions = "With Distinction";
} else if (score >= 70) {
    grade = "C";
    distinctions = "With Distinction";
} else if (score >= 60) {
    grade = "D";
} else {
    grade = "F";
}

// Check if the student earned distinctions.
if (score >= distinctionThreshold) {
    distinctions = "With Distinction";
} else {
    distinctions = "Without Distinction";
}

// Display the result and distinctions.
console.log(`Score: ${score}`);
console.log(`Grade: ${grade}`);
console.log(`Distinctions: ${distinctions}`);
