// Define the total marks obtained by the student and the number of subjects.
const totalMarks = 95;
const numberOfSubjects = 3;

// Calculate the result mark.
const resultMark = totalMarks / numberOfSubjects;

// Function to grade the student based on their result mark.
function gradeStudent(resultMark) {
  if (resultMark >= 90) {
    return "A";
  } else if (resultMark >= 80) {
    return "B";
  } else if (resultMark >= 70) {
    return "C";
  } else if (resultMark >= 60) {
    return "D";
  } else {
    return "F";
  }
}

// Get the student's grade.
const grade = gradeStudent(resultMark);

// Display the student's grade to the user.
console.log(`Grade: ${grade}`);

