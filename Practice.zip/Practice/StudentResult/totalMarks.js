// Create a variable to store the total marks.
let totalMarks = 0;

// Calculate the total marks by adding up the marks for each individual subject.
totalMarks += 90; // English
totalMarks += 85; // Maths
totalMarks += 95; // Science

// Calculate the result mark by dividing the total marks by the number of subjects.
const resultMark = totalMarks / 3;

// Display the result mark to the user.
console.log(`Result mark: ${resultMark}`);
