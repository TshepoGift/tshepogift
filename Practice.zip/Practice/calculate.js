//How to calculate age from DOB
const calculateAge = (dob) => {
    const birthDate = new Date(dob);
    const dateDiffMs = Date.now() - birthDate.getTime();
    const ageYear = new Date(dateDiffMs);
    return Math.abs(2023 - ageYear.getFullYear());
}

const dateOfBirth = "1997";
console.log("Result", calculateAge(dateOfBirth));