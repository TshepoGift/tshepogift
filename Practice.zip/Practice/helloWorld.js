console.log("Hello, World");

function helloWorld(firstName, firstSurname, age){
    console.log("My name is " + firstName + firstSurname + ". You are " + age + " year old.");
}
let firstName = "Tshepo ";
let firstSurname = "Makgale";
let age = 26;

helloWorld(firstName, firstSurname, age);