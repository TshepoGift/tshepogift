// Define a function to calculate annual salary
function calculateAnnualSalary(employee) {
    const { name, salary } = employee;
    const baseSalary = salary * 12; // Calculate base salary
    const bonusPercentage = 10; // 10% bonus
    const bonus = (bonusPercentage / 100) * baseSalary; // Calculate bonus
    return baseSalary + bonus; // Calculate and return annual salary with bonus
}

// Create two Manager objects
const manager1 = { name: 'Angela Luca', salary: 50000 };
const manager2 = { name: 'Jonelle Rozaliya', salary: 53500 };

// Calculate the annual salary for each manager
const annualSalary1 = calculateAnnualSalary(manager1);
const annualSalary2 = calculateAnnualSalary(manager2);

// Display the annual salary for each manager
console.log(`Manager: ${manager1.name}, Annual Salary: R$${annualSalary1}`);
console.log(`Manager: ${manager2.name}, Annual Salary: R$${annualSalary2}`);


    