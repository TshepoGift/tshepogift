//Write a JavaScript program that creates a class called 'Employee' with properties for name and salary. 
//Include a method to calculate annual salary. Create a subclass called 'Manager' that inherits from the 'Employee' class and adds an additional property for department. 
//Override the annual salary calculation method to include bonuses for managers. Create two instances of the 'Manager' class and calculate their annual salary.

// Define an Employee class
class Employee {
    constructor(name, salary) {
      this.name = name;
      this.salary = salary;
      console.log(`Name: ${name}`);
      console.log(`Salary: R${salary}`);
    }
  
    calculateAnnualSalary() {
      return this.salary * 12; // Calculate annual salary
    }
  }
  
  // Define a Manager class that extends Employee
  class Manager extends Employee {
    constructor(name, salary, department) {
      super(name, salary); // Call the parent class constructor
      this.department = department;
    }
  
    calculateAnnualSalary() {
      const baseSalary = super.calculateAnnualSalary();
      const bonusPercentage = 10; // 10% bonus
      const bonus = (bonusPercentage / 100) * baseSalary; // Calculate bonus
      return baseSalary + bonus; // Calculate and return annual salary with bonus
    }
  }
  
  // Create a Manager instance - manager1
  const manager1 = new Manager('Angela Luca', 50000, 'Marketing');
  const annualSalary1 = manager1.calculateAnnualSalary();
  
  // Display manager1's information and annual salary
  console.log(`Manager: ${manager1.name}`);
  console.log(`Department: ${manager1.department}`);
  console.log(`Annual Salary: R${annualSalary1}`);
  
  // Create another Manager instance - manager2
  const manager2 = new Manager('Jonelle Rozaliya', 53500, 'Marketing');
  const annualSalary2 = manager2.calculateAnnualSalary();
  
  // Display manager2's information and annual salary
  console.log(`Manager: ${manager2.name}`);
  console.log(`Department: ${manager2.department}`);
  console.log(`Annual Salary: R${annualSalary2}`);
  