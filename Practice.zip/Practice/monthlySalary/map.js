let arr = [23, 43, 56, 87, 99, 97, 23]
//forEach use a function and not method
let a = arr.forEach((num) =>{
    return num * 2
});

//map use a method
let b = arr.map((num) =>{
    return num * 2;
});

//find: It stops when it finds the first oocurence of
//matches the condition
arr;
/*let wasFound = arr.find((val)=>{
    return val===34
});
wasFound
*/

let wasFound = arr.filter((val)=>{
    //return val>4
    return !(val % 2);
});
wasFound;
