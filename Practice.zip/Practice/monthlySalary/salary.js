// Define an Employee class
class Employee {
    constructor(name, salary) {
      this.name = name;
      this.salary = salary;
      console.log(`Name: ${name}`);
      console.log(`Salary: R${salary}`);
    }
  
    calculateAnnualSalary() {
      return this.salary * 12; // Calculate annual salary
    }
  }
  
  // Define a Manager class that extends Employee
  class Manager extends Employee {
    constructor(name, salary, department) {
      super(name, salary); // Call the parent class constructor
      this.department = department;
    }
  
    calculateAnnualSalary() {
      const baseSalary = super.calculateAnnualSalary();
      const bonusPercentage = 10; // 10% bonus
      const bonus = (bonusPercentage / 100) * baseSalary; // Calculate bonus
      return baseSalary + bonus; // Calculate and return annual salary with bonus
    }
  }
  
  // Function to calculate and display the annual salary for a manager
  function calculateAndDisplayAnnualSalary(manager) {
    const annualSalary = manager.calculateAnnualSalary();
    console.log(`Manager: ${manager.name}`);
    console.log(`Department: ${manager.department}`);
    console.log(`Annual Salary: R${annualSalary}`);
  }
  
  // Create a Manager instance - manager1
  const manager1 = new Manager('Angela Luca', 5000, 'Marketing');
  calculateAndDisplayAnnualSalary(manager1);
  
  // Create another Manager instance - manager2
  const manager2 = new Manager('Jonelle Rozaliya', 5500, 'Marketing');
  calculateAndDisplayAnnualSalary(manager2);
  