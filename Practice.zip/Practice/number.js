//How to print n to 1 number in JavaScript using For loop
/*let number = n
for(i=1; i>=n; i--){
    console.log(i);
}*/

function printNumbers(num){
    if (num < 1){
        console.error('num must be greater than 1');
        return;
    }
    if (!Number.isInteger(num)){
        num = Math.trunc(num);
    }
    for (let i=num; i > 0; i--){
        console.info(i);
    }
}
printNumbers(10);