//How to print 1 to n number in JavaScript using For loop
/*let n = number
for(i=1; i<=n; i++){
    console.log(i);
}*/
/*function primeNumbers(n){
    for(let i=1; i<=n; i++){
        console.log(i);
    }
}
const n = 10;
console.log(primeNumbers);*/
/*function printNumbers(args){
    let input = args[0];
    for (let i=1; i<=input; i++){
        console.log(i);
    }
}*/

function printNumbers(num){
    if (num < 1){
        console.error('num must be greater than 1');
        return;
    }
    if (!Number.isInteger(num)){
        num = Math.trunc(num);
    }
    for (let i=1; i<= num; i++){
        console.info(i);
    }
}
printNumbers(10);