function generateUniqueRandomArray(min, max, size= 10){
    const set = new Set();
    while(set.size<size){
        const number = Math.floor(Math.random() * (max - min)) + min;
        set.add(number);
    }
    return[...set];
}