let myNum = 123;
console.log(typeof myNum);

myNum = 1.23445454;
console.log(typeof myNum);

myNum = 5e4;
console.log(typeof myNum);

let someStr = "12322323232";
console.log(typeof someStr);