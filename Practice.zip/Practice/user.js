let user = "John", loggedIn = true;
if(user === null){
    loggedIn = false;
    user = 'Guest'
}

console.log('Welcome ' + user);